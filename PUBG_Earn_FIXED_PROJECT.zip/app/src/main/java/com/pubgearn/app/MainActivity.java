package com.pubgearn.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.net.Uri;
import android.webkit.*;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String CHANNEL_ID = "pubg_earn";

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createChannel();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
        webView = new WebView(this); setContentView(webView);
        WebSettings settings=webView.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setDatabaseEnabled(true); settings.setAllowFileAccess(true); settings.setAllowContentAccess(true); settings.setBuiltInZoomControls(false); settings.setDisplayZoomControls(false);
        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }
    private void createChannel(){ if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel(CHANNEL_ID,"PUBG Earn",NotificationManager.IMPORTANCE_HIGH); c.setDescription("PUBG Earn order and chat notifications"); getSystemService(NotificationManager.class).createNotificationChannel(c); }}
    public class AndroidBridge { @JavascriptInterface public void notify(String title,String text){ runOnUiThread(()->{ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return; Notification n=new Notification.Builder(MainActivity.this,CHANNEL_ID).setSmallIcon(com.pubgearn.app.R.drawable.ic_launcher).setContentTitle(title).setContentText(text).setAutoCancel(true).setStyle(new Notification.BigTextStyle().bigText(text)).build(); getSystemService(NotificationManager.class).notify((int)(System.currentTimeMillis()&0x7fffffff),n); }); }}
    @Override public void onBackPressed(){ if(webView!=null&&webView.canGoBack())webView.goBack(); else super.onBackPressed(); }
}
