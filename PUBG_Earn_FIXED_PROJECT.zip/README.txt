PUBG Earn — Android Studio / Play Store project

Open the project folder in Android Studio and let Gradle sync.
Build > Generate Signed Bundle / APK > Android App Bundle.

The project targets compileSdk/targetSdk 36, because Google Play requires new apps and updates to target Android 16 (API 36) or higher from 31 August 2026.

Customer accounts in this version are local-demo accounts only. They are NOT suitable for production because they do not provide a shared server database or secure password authentication.
