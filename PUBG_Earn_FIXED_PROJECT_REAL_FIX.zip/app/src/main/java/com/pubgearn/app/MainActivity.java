package com.pubgearn.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.webkit.*;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String CHANNEL_ID = "pubg_earn";

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createChannel();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
        webView = new WebView(this); setContentView(webView);
        WebSettings settings=webView.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setDatabaseEnabled(true); settings.setAllowFileAccess(true); settings.setAllowContentAccess(true); settings.setBuiltInZoomControls(false); settings.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        // Give the Firebase Web SDK a secure HTTPS origin instead of file://.
        // This is required for Firebase Auth persistence/authorized-domain checks in WebView.
        webView.loadDataWithBaseURL(
                "https://pubg-earn-3f82e.firebaseapp.com/",
                readAsset("index.html"),
                "text/html",
                "UTF-8",
                "https://pubg-earn-3f82e.firebaseapp.com/"
        );
    }
    private String readAsset(String name) throws RuntimeException {
        try (java.io.InputStream in = getAssets().open(name);
             java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toString(java.nio.charset.StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            throw new RuntimeException("Unable to load app UI", e);
        }
    }

    private void createChannel(){ if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel(CHANNEL_ID,"PUBG Earn",NotificationManager.IMPORTANCE_HIGH); c.setDescription("PUBG Earn order and chat notifications"); getSystemService(NotificationManager.class).createNotificationChannel(c); }}
    public class AndroidBridge { @JavascriptInterface public void notify(String title,String text){ runOnUiThread(()->{ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return; Notification n=new Notification.Builder(MainActivity.this,CHANNEL_ID).setSmallIcon(com.pubgearn.app.R.drawable.ic_launcher).setContentTitle(title).setContentText(text).setAutoCancel(true).setStyle(new Notification.BigTextStyle().bigText(text)).build(); getSystemService(NotificationManager.class).notify((int)(System.currentTimeMillis()&0x7fffffff),n); }); }}
    @Override public void onBackPressed(){ if(webView!=null&&webView.canGoBack())webView.goBack(); else super.onBackPressed(); }
}
